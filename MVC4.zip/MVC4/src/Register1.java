

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
public class Register1 extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest request, HttpServletResponse response)
	{
		try
		{
		String StudentName = request.getParameter("sn");
		String StudentUsn = request.getParameter("su");
		String StudentBranch = request.getParameter("sb");
		String StudentSem = request.getParameter("ss");
		int sem=new Integer(StudentSem);
		String StudentGender = request.getParameter("sg");
		String fee=request.getParameter("fee");
		int fee1=new Integer(fee);
		String feepaid=request.getParameter("feepaid");
		int feepaid1=new Integer(feepaid);
		int feebalance=fee1-feepaid1;
		System.out.println(StudentName);
		System.out.println("this is register1");
		System.out.println("control is in register 1");
		
		Model1 m1=new Model1();
		
		m1.setSn(StudentName);
		m1.setSu(StudentUsn);
		m1.setSb(StudentBranch);
		m1.setSs(sem);
		m1.setSg(StudentGender);
		m1.setFee(fee1);
		m1.setFeepaid(feepaid1);
		m1.setFeebalance(feebalance);
		
		
		boolean status = m1.register2();
		System.out.println("hello");
		
		if(status==true)
		{
			System.out.println("hello if");
			response.sendRedirect("/MVC4/addsuccess.jsp");
		}
		else
		{
			System.out.println("hello else");
			response.sendRedirect("/MVC4/addFail.jsp");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
