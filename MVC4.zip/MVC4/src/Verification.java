

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Verification extends HttpServlet
{
	public void service(HttpServletRequest request, HttpServletResponse response)
	{
	try
	  {
		  String temp1=request.getParameter("aun");
		  String temp2=request.getParameter("apw");
		  Model1 m1=new Model1();
		  m1.setAun(temp1);
		  m1.setApw(temp2);
		  m1.verifiction();
		  String b1=m1.getB();
		  String c1=m1.getC();
		  if((temp1.equals(b1)) && (temp2.equals(c1)))
		  {
			response.sendRedirect("/MVC4/addView.jsp"); 
		  }
		  else
		  {
			  response.sendRedirect("/MVC4/notExist.jsp");
		  }
		  
				  
	  }
	catch(Exception e)
	{
		e.printStackTrace();
	}
   }
}