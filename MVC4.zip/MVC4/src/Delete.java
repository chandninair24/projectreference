

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Delete
 */
public class Delete extends HttpServlet 
{
	public void service(HttpServletRequest request,HttpServletResponse response)
	{
		try
		{
			String AccountName = request.getParameter("acc");
			Model1 m1= new Model1();
			m1.setAcc(AccountName);
			m1.delete();
			boolean status = m1.delete();
			if(status==true)
			{
				response.sendRedirect("/MVC4/deleteSuccess.jsp");
			}
			else
			{
				response.sendRedirect("/MVC4/deleteFail.jsp");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
