

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
public class Register extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest request, HttpServletResponse response)
	{
		try
		{
		String AccountName = request.getParameter("acc");
		String username = request.getParameter("aun");
		String password = request.getParameter("apw");
		
		Model1 m1=new Model1();
		m1.setAcc(AccountName);
		m1.setAun(username);
		m1.setApw(password);
		boolean status = m1.register1();
		if(status==true)
		{
			response.sendRedirect("/MVC4/registerSuccessful.jsp");
		}
		else
		{
			response.sendRedirect("/MVC4/registerFail.jsp");
		}	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
