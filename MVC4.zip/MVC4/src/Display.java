

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Display
 */
public class Display extends HttpServlet 
{

	private String name1;
	private String usn1;
	private String branch1;
	private int sem1;
	private String gender1;
	private int fee2;
	private int paid1;
	private int balance1;

	public void service(HttpServletRequest request, HttpServletResponse response)
	{
		try
		{
		String StudentName = request.getParameter("sn");
	    Model1 m1= new Model1();
	    m1.setSn(StudentName);
		m1.view();
		String name=m1.getName();
		String usn=m1.getUsn();
		String branch=m1.getBranch();
		int sem=m1.getSem();
		String gender=m1.getGender();
		int fee2=m1.getFee2();
		int paid1=m1.getPaid();
		int balance1=m1.getBalance();
		
		HttpSession session=request.getSession(true);
		session.setAttribute("NAME", name);
		session.setAttribute("USN", usn);
		session.setAttribute("BRANCH", branch);
		session.setAttribute("SEM", sem);
		session.setAttribute("GENDER", gender);
		session.setAttribute("FEE2", fee2);
		session.setAttribute("PAID", paid1);
		session.setAttribute("BALANCE", balance1);
		response.sendRedirect("/MVC4/disp.jsp");
		
		
        
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getUsn1() {
		return usn1;
	}

	public void setUsn1(String usn1) {
		this.usn1 = usn1;
	}

	public String getBranch1() {
		return branch1;
	}

	public void setBranch1(String branch1) {
		this.branch1 = branch1;
	}

	public int getSem1() {
		return sem1;
	}

	public void setSem1(int sem1) {
		this.sem1 = sem1;
	}

	public String getGender1() {
		return gender1;
	}

	public void setGender1(String gender1) {
		this.gender1 = gender1;
	}

	public int getFee2() {
		return fee2;
	}

	public void setFee2(int fee2) {
		this.fee2 = fee2;
	}

		public int getPaid1() {
		return paid1;
	}

	public void setPaid1(int paid1) {
		this.paid1 = paid1;
	}

	public int getBalance1() {
		return balance1;
	}

	public void setBalance1(int balance1) {
		this.balance1 = balance1;
	}
    
}
