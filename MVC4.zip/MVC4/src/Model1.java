import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import oracle.jdbc.driver.OracleDriver;

public class Model1 
{
	private String acc;
	private String aun;
	private String apw;
	
	private String sn;
	private String su;
	private String sb;
	private int ss;
	private String sg;
	private int fee;
	private int feepaid;
	private int feebalance;
	
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet res=null;
	String url = "jdbc:oracle:thin:@//localhost:1521/XE";
	String un = "system";
	String pw = "system";
	
	private String a;
	private String b;
	private String c;
	
	private String name;
	private String usn;
	private String branch;
	private int sem;
	private String gender;
	private int fee2;
	private int paid;
	private int balance;
	
		
	public Model1() throws Exception
	{
		DriverManager.registerDriver(new OracleDriver());
		con = DriverManager.getConnection(url,un,pw);
		System.out.println("data base is connected");
	}
	
	
	public boolean register1()
	{
		try 
		{
			String s = "INSERT INTO ADDACCOUNTANT VALUES (?,?,?)";
			pstmt = con.prepareStatement(s);
			pstmt.setString(1, acc);
			pstmt.setString(2, aun);
			pstmt.setString(3, apw);
			int row = pstmt.executeUpdate();
			
			if(row>=0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	
	
	public boolean register2() 
	{
		try
		{
			String s1="INSERT INTO ADDSTUDENT VALUES(?,?,?,?,?,?,?,?)";
			pstmt= con.prepareStatement(s1);
			pstmt.setString(1, sn);
			pstmt.setString(2, su);
			pstmt.setString(3, sb);
			pstmt.setInt(4, ss);
			pstmt.setString(5, sg);
			pstmt.setInt(6, fee);
			pstmt.setInt(7, feepaid);
			pstmt.setInt(8, feebalance);
			System.out.println(sn);
			int row=pstmt.executeUpdate();
			
			System.out.println("display the details");
			if(row>0)
			{
				System.out.println("if block");
				return true;
			}
			else
			{
				System.out.println("else block");
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("elseif block");
	  return false;	
	}
	
	
	
	 public boolean delete()
	 {
		 try
		 {
			String s= "DELETE FROM ADDACCOUNTANT WHERE Account_Name=?";
			pstmt = con.prepareStatement(s);
			pstmt.setString(1, acc);
			int rows=pstmt.executeUpdate();
			if(rows>=0)
			{
				return true;
			}
			else
			{
				return false;
			}
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		 return false;
	 }
	 
	 
	 
	 
	 public void verifiction()
	 {
		 try
		 {
			 String s1 ="select * from ADDACCOUNTANT where ACCOUNT_USERNAME=? AND ACCOUNT_PASSWORD=?";
			 pstmt = con.prepareStatement(s1);
			 pstmt.setString(1, aun);
			 pstmt.setString(2,apw);
			 res=pstmt.executeQuery();
			 while(res.next()==true)
			 {
				 a=res.getString(1);
				 b=res.getString(2);
				 c=res.getString(3);
			 }  
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	 }
	 
     
	 
	 
	 public void view()
      {
	    try 
	    {
	    	String s="SELECT * FROM ADDSTUDENT WHERE Student_Name=? ";
	    	 pstmt = con.prepareStatement(s);
			 pstmt.setString(1, sn);
			 res=pstmt.executeQuery();
			 System.out.println("i am not sure");
			 if(res.next()==true)
			 {
				 System.out.println("hello world");
				 name=res.getString(1);
				 usn=res.getString(2);
				 branch=res.getString(3);
				 sem=res.getInt(4);
				 gender=res.getString(5);
				 fee2=res.getInt(6);
				 paid=res.getInt(7);
				 balance=res.getInt(8);
				System.out.println("i am the end");
     		 }
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
      }
	 
	 
	 
	 
	public String getAcc() {
		return acc;
	}

	public void setAcc(String acc) {
		this.acc = acc;
	}
    
	public String getAun() {
		return aun;
	}

	public void setAun(String aun) {
		this.aun = aun;
	}
	
	public String getApw() {
		return apw;
	}

	public void setApw(String apw) {
		this.apw = apw;
	}

	
	
	
	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}

	
	
	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getSu() {
		return su;
	}

	public void setSu(String su) {
		this.su = su;
	}

	public String getSb() {
		return sb;
	}

	public void setSb(String sb) {
		this.sb = sb;
	}

	public int getSs() {
		return ss;
	}

	public void setSs(int StudentSem) {
		this.ss = StudentSem;
	}

	public String getSg() {
		return sg;
	}

	public void setSg(String sg) {
		this.sg = sg;
	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

	public int getFeepaid() {
		return feepaid;
	}

	public void setFeepaid(int feepaid) {
		this.feepaid = feepaid;
	}

	public int getFeebalance() {
		return feebalance;
	}

	public void setFeebalance(int feebalance) {
		this.feebalance = feebalance;
	}

	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsn() {
		return usn;
	}

	public void setUsn(String usn) {
		this.usn = usn;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public int getSem() {
		return sem;
	}

	public void setSem(int sem) {
		this.sem = sem;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getFee2() {
		return fee2;
	}

	public void setFee2(int fee2) {
		this.fee2 = fee2;
	}

	public int getPaid() {
		return paid;
	}

	public void setPaid(int paid) {
		this.paid = paid;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	
	
	
	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}
}
