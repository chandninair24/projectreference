

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Validation
 */
public class Validation extends HttpServlet 
{
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public void service(HttpServletRequest request,HttpServletResponse response)
  {
	  try
	  {
		  String username=request.getParameter("un");
		  String password=request.getParameter("pw");
		  if(username.equals("ABC") && password.equals("abcforjava"))
		  {
			  response.sendRedirect("/MVC4/Admin1.jsp");
		  }
		  else
		  {
			  response.sendRedirect("/MVC4/error.jsp");
		  }
		  
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
  }
}
